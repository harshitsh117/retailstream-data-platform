"""
Configuration models.
"""